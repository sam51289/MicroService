package com.way2learnonline.paymentservice.aggregates;

public enum InvoiceStatus {

    PAID, PAYMENT_REVERSED
}
