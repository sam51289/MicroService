package com.way2learnonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CqrsQueryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CqrsQueryAppApplication.class, args);
	}

}
